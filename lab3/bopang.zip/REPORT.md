# Lab3 report:

**I use 3 free days in this lab. I have one free day left.**

I implemented three recursive functions to do the task. And call the recursive function in the insert, delete and lookup.

I get 100 point. And pass all test cases.



